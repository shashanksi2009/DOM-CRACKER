//https://www.tutorialspoint.com/videotutorials/index.htm
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$( function() {
  $( "div" ).draggable();
} );
</script>
<style>
  div:hover{
    box-shadow: 0 0 5px 1px lightblue;
  }
</style>
